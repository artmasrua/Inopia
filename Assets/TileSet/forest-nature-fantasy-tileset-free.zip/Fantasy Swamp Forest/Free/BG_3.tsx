<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="BG_3" tilewidth="16" tileheight="16" tilecount="3200" columns="128">
 <image source="BG_3/BG_3.png" width="2048" height="400"/>
</tileset>
