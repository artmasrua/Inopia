<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Sale-board" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="../../../../Marketing/Sale-board.png" trans="9e9e9e" width="64" height="64"/>
</tileset>
